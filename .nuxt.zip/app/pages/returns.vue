<!-- app/pages/returns.vue -->
<template>
  <div class="bg-[#d6f8f7] min-h-screen">
    <div class="max-w-[1300px] mx-auto p-10">
      <h1 class="text-4xl font-bold text-[#013087] mb-4">
        Returns Made Simple
      </h1>

      <p class="text-lg text-gray-700 mb-8">
        Whether you shop or sell, we make returns easy.
      </p>

      <div class="grid grid-cols-2 gap-6">
        <div class="bg-[#14d3ca] p-8 rounded-xl text-white">
          <h2 class="text-2xl font-semibold mb-2">I shop on eBay.</h2>
          <p class="mb-4">
            Not exactly what you expected? Not to worry. We keep returns simple.
          </p>
          <button class="px-4 py-2 bg-white text-black rounded-full text-sm">
            Learn More →
          </button>
        </div>

        <div class="bg-[#25cbd0] p-8 rounded-xl text-white">
          <h2 class="text-2xl font-semibold mb-2">I sell on eBay.</h2>
          <p class="mb-4">
            Give buyers another reason to love your listings by offering returns.
          </p>
          <button class="px-4 py-2 bg-white text-black rounded-full text-sm">
            Learn More →
          </button>
        </div>
      </div>
    </div>
  </div>
</template>
