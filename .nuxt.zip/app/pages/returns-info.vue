<template>
  <div>
    <ReturnsSpotlight />
    <ReturnsFeaturedDeals />
  </div>
</template>

<script setup lang="ts">
import ReturnsSpotlight from '~/components/organisms/ReturnsSpotlight.vue'
import ReturnsFeaturedDeals from '~/components/organisms/ReturnsFeaturedDeals.vue'
</script>

<style scoped>
/* Stil düzenlemeleri buraya eklenebilir */
</style>
