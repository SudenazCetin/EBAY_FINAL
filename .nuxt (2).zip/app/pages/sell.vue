<!-- app/pages/sell.vue -->
<script setup lang="ts">
// Sell sayfası - şimdilik Home'a benzer bir placeholder
</script>

<template>
  <div class="max-w-5xl mx-auto px-4 py-12 text-center">
    <h1 class="text-3xl font-bold mb-4">Sell on eBay</h1>
    <p class="text-gray-600 mb-8">
      Reach millions of buyers worldwide. Start selling today!
    </p>
    
    <div class="bg-white rounded-xl shadow-lg p-8 max-w-md mx-auto">
      <h2 class="text-xl font-semibold mb-4">Ready to start?</h2>
      <p class="text-gray-500 mb-6">
        Create your listing in minutes. Payments, shipping, and customer service — all handled.
      </p>
      <button class="bg-blue-600 text-white px-8 py-3 rounded-full font-semibold hover:bg-blue-700">
        List an item
      </button>
    </div>
  </div>
</template>
