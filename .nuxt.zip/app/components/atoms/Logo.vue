<!-- app/components/atoms/Logo.vue -->
<script setup lang="ts">
</script>

<template>
  <div class="inline-flex items-center gap-0 text-3xl font-semibold tracking-normal select-none">
     <span class="text-5xl font-medium tracking-tighter text-[#e53238]">e</span>
     <span class="text-5xl font-medium tracking-tighter text-[#0064d2]">b</span>
     <span class="text-5xl font-medium tracking-tighter text-[#f5af02]">a</span>
     <span class="text-5xl font-medium tracking-tighter text-[#86b817]">y</span>
  </div>
</template>
