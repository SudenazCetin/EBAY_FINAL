<!-- app/layouts/auth.vue -->
<!-- Login ve Register sayfaları için header/footer olmadan layout -->
<template>
  <div class="min-h-screen bg-white">
    <slot />
  </div>
</template>
