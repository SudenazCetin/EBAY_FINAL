<!-- app/components/organisms/FooterBar.vue -->
<script setup lang="ts">
</script>

<template>
  <footer class="bg-[#f5f5f5] border-t mt-8">
    <div class="max-w-7xl mx-auto px-6 py-10 text-sm text-gray-700">

      <!-- GERÇEK EBAY SIRASI -->
      <div class="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-8 mb-10">

        <!-- BUY -->
        <div>
          <h3 class="font-bold mb-3 text-sm uppercase">Buy</h3>
          <ul class="space-y-1 text-[14px]">
            <li><a href="#" class="hover:underline">Registration</a></li>
            <li><a href="#" class="hover:underline">Bidding & buying help</a></li>
            <li><a href="#" class="hover:underline">Stores</a></li>
            <li><a href="#" class="hover:underline">Creator Collections</a></li>
            <li><a href="#" class="hover:underline">eBay for Charity</a></li>
            <li><a href="#" class="hover:underline">Charity Shop</a></li>
            <li><a href="#" class="hover:underline">Seasonal sales and events</a></li>
            <li><a href="#" class="hover:underline">eBay Gift Cards</a></li>
          </ul>
        </div>

        <!-- SELL -->
        <div>
          <h3 class="font-bold mb-3 text-sm uppercase">Sell</h3>
          <ul class="space-y-1 text-[14px]">
            <li><a href="#" class="hover:underline">Start selling</a></li>
            <li><a href="#" class="hover:underline">How to sell</a></li>
            <li><a href="#" class="hover:underline">Business sellers</a></li>
            <li><a href="#" class="hover:underline">Affiliates</a></li>
          </ul>
        </div>

        <!-- TOOL & APPS -->
        <div>
          <h3 class="font-bold mb-3 text-sm uppercase">Tools & apps</h3>
          <ul class="space-y-1 text-[14px]">
            <li><a href="#" class="hover:underline">Developers</a></li>
            <li><a href="#" class="hover:underline">Security center</a></li>
            <li><a href="#" class="hover:underline">Site map</a></li>
          </ul>
        </div>

        <!-- eBay companies -->
        <div>
          <h3 class="font-bold mb-3 text-sm uppercase">eBay companies</h3>
          <ul class="space-y-1 text-[14px]">
            <li><a href="#" class="hover:underline">TCGplayer</a></li>
          </ul>

          <h3 class="font-bold mt-6 mb-3 text-sm uppercase">Stay connected</h3>
          <ul class="space-y-1 text-[14px]">
            <li><a href="#" class="hover:underline">Facebook</a></li>
            <li><a href="#" class="hover:underline">X (Twitter)</a></li>
          </ul>
        </div>

        <!-- ABOUT EBAY -->
        <div>
          <h3 class="font-bold mb-3 text-sm uppercase">About eBay</h3>
          <ul class="space-y-1 text-[14px]">
            <li><a href="#" class="hover:underline">Company info</a></li>
            <li><a href="#" class="hover:underline">News</a></li>
            <li><a href="#" class="hover:underline">Investors</a></li>
            <li><a href="#" class="hover:underline">Careers</a></li>
            <li><a href="#" class="hover:underline">Diversity & Inclusion</a></li>
            <li><a href="#" class="hover:underline">Global Impact</a></li>
            <li><a href="#" class="hover:underline">Government relations</a></li>
            <li><a href="#" class="hover:underline">Advertise with us</a></li>
            <li><a href="#" class="hover:underline">Policies</a></li>
            <li><a href="#" class="hover:underline">eCI Licenses</a></li>
          </ul>
        </div>

        <!-- HELP + COMMUNITY -->
        <div>
          <h3 class="font-bold mb-3 text-sm uppercase">Help & Contact</h3>
          <ul class="space-y-1 text-[14px] mb-6">
            <li><a href="#" class="hover:underline">Seller Center</a></li>
            <li><a href="#" class="hover:underline">Contact Us</a></li>
            <li><a href="#" class="hover:underline">eBay Returns</a></li>
            <li><a href="#" class="hover:underline">eBay Money Back Guarantee</a></li>
          </ul>

          <h3 class="font-bold mb-3 text-sm uppercase">Community</h3>
          <ul class="space-y-1 text-[14px]">
            <li><a href="#" class="hover:underline">Announcements</a></li>
            <li><a href="#" class="hover:underline">eBay Community</a></li>
            <li><a href="#" class="hover:underline">eBay for Business Podcast</a></li>
          </ul>
        </div>

      </div>

      <!-- Alt Legal -->
      <div class="border-t pt-4 flex flex-col md:flex-row items-center justify-between gap-2 text-xs text-gray-500">
        <div>© 2025 eBay Clone. All Rights Reserved.</div>

        <div class="flex flex-wrap gap-x-3 gap-y-2 justify-center">
          <a href="#" class="hover:underline">Accessibility</a>
          <a href="#" class="hover:underline">User Agreement</a>
          <a href="#" class="hover:underline">Privacy</a>
          <a href="#" class="hover:underline">Cookies</a>
        </div>
      </div>

    </div>
  </footer>
</template>
